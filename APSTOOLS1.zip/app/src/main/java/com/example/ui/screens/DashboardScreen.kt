package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ads.StickyBannerAd
import com.example.billing.BillingManager
import com.example.model.AppPreferencesManager
import com.example.model.AppScreen
import com.example.model.ThemeMode
import com.example.model.ToolCategory
import com.example.ui.components.ProUpgradeDialog
import com.example.ui.components.ThemeSwitcherDialog
import com.example.ui.theme.AgeOrange
import com.example.ui.theme.AgeOrangeBg
import com.example.ui.theme.ApsBlue
import com.example.ui.theme.CategoryImageBg
import com.example.ui.theme.CategoryImageBlue
import com.example.ui.theme.DiscountPurple
import com.example.ui.theme.DiscountPurpleBg
import com.example.ui.theme.EmiGreen
import com.example.ui.theme.EmiGreenBg
import com.example.ui.theme.GstBlue
import com.example.ui.theme.GstBlueBg
import com.example.ui.theme.NotesSlate
import com.example.ui.theme.NotesSlateBg
import com.example.ui.theme.ProGold
import com.example.ui.theme.ProGoldBg
import com.example.ui.theme.QrIndigo
import com.example.ui.theme.QrIndigoBg
import com.example.ui.theme.Slate700
import com.example.ui.theme.Slate900
import com.example.ui.theme.SplitTeal
import com.example.ui.theme.SplitTealBg
import com.example.utils.HapticUtils

data class ToolDefinition(
    val screen: AppScreen,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val category: ToolCategory,
    val accentColor: Color,
    val backgroundColor: Color,
    val testTag: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    billingManager: BillingManager,
    onNavigateToTool: (AppScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val preferencesManager = remember { AppPreferencesManager.getInstance(context) }
    val favoriteScreens by preferencesManager.favoriteTools.collectAsState()
    val themeMode by preferencesManager.themeMode.collectAsState()
    val isSystemDark = isSystemInDarkTheme()
    val isCurrentlyDark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemDark
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val isPremium by billingManager.isPremium.collectAsState()
    var showProDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(ToolCategory.ALL) }
    var showOnlyFavorites by remember { mutableStateOf(false) }

    val allTools = remember {
        listOf(
            // Image & Doc Tools
            ToolDefinition(
                screen = AppScreen.PHOTO_COMPRESSOR,
                title = "Photo Compressor",
                description = "Reduce KB/MB file size up to 90% while keeping sharp visual clarity.",
                icon = Icons.Default.Compress,
                category = ToolCategory.IMAGE_DOC,
                accentColor = CategoryImageBlue,
                backgroundColor = CategoryImageBg,
                testTag = "tool_card_compressor"
            ),
            ToolDefinition(
                screen = AppScreen.IMAGE_RESIZER,
                title = "Image Resizer",
                description = "Change image dimensions with aspect ratio lock and quick scaling presets.",
                icon = Icons.Default.AspectRatio,
                category = ToolCategory.IMAGE_DOC,
                accentColor = CategoryImageBlue,
                backgroundColor = CategoryImageBg,
                testTag = "tool_card_resizer"
            ),
            ToolDefinition(
                screen = AppScreen.IMAGE_TO_PDF,
                title = "Image to PDF",
                description = "Convert one or multiple gallery photos into a multi-page A4 PDF file.",
                icon = Icons.Default.PictureAsPdf,
                category = ToolCategory.IMAGE_DOC,
                accentColor = CategoryImageBlue,
                backgroundColor = CategoryImageBg,
                testTag = "tool_card_image_to_pdf"
            ),

            // Financial & Utility Tools
            ToolDefinition(
                screen = AppScreen.GST_CALCULATOR,
                title = "GST Calculator",
                description = "Add or remove GST with 5%, 12%, 18%, 28% slabs and CGST/SGST split.",
                icon = Icons.Default.ReceiptLong,
                category = ToolCategory.FINANCE,
                accentColor = GstBlue,
                backgroundColor = GstBlueBg,
                testTag = "tool_card_gst"
            ),
            ToolDefinition(
                screen = AppScreen.LOAN_EMI_CALCULATOR,
                title = "Loan EMI",
                description = "Calculate monthly installments, total interest, and principal vs interest ratio.",
                icon = Icons.Default.AccountBalance,
                category = ToolCategory.FINANCE,
                accentColor = EmiGreen,
                backgroundColor = EmiGreenBg,
                testTag = "tool_card_emi"
            ),
            ToolDefinition(
                screen = AppScreen.AGE_CALCULATOR,
                title = "Age Calculator",
                description = "Compute exact age in years, months, and days with next birthday countdown.",
                icon = Icons.Default.Cake,
                category = ToolCategory.FINANCE,
                accentColor = AgeOrange,
                backgroundColor = AgeOrangeBg,
                testTag = "tool_card_age"
            ),
            ToolDefinition(
                screen = AppScreen.SPLIT_BILL,
                title = "Split Bill",
                description = "Split restaurant bills and tips evenly among groups of friends.",
                icon = Icons.Default.Payments,
                category = ToolCategory.FINANCE,
                accentColor = SplitTeal,
                backgroundColor = SplitTealBg,
                testTag = "tool_card_split_bill"
            ),
            ToolDefinition(
                screen = AppScreen.DISCOUNT_CALCULATOR,
                title = "Discount Calculator",
                description = "Determine net price after discounts and see exact currency saved.",
                icon = Icons.Default.LocalOffer,
                category = ToolCategory.FINANCE,
                accentColor = DiscountPurple,
                backgroundColor = DiscountPurpleBg,
                testTag = "tool_card_discount"
            ),

            // Daily Quick Tools
            ToolDefinition(
                screen = AppScreen.QR_CODE_TOOL,
                title = "QR Code Generator & Scanner",
                description = "Generate crisp QR codes or scan QR codes directly from gallery photos.",
                icon = Icons.Default.QrCode,
                category = ToolCategory.DAILY,
                accentColor = QrIndigo,
                backgroundColor = QrIndigoBg,
                testTag = "tool_card_qr"
            ),
            ToolDefinition(
                screen = AppScreen.NOTES_COUNTER,
                title = "Notes & Character Counter",
                description = "Live word & character counter, reading time estimates, and text case tools.",
                icon = Icons.Default.Notes,
                category = ToolCategory.DAILY,
                accentColor = NotesSlate,
                backgroundColor = NotesSlateBg,
                testTag = "tool_card_notes"
            )
        )
    }

    val filteredTools = remember(searchQuery, selectedCategory, showOnlyFavorites, favoriteScreens, allTools) {
        val baseList = allTools.filter { tool ->
            val matchesFavorite = !showOnlyFavorites || favoriteScreens.contains(tool.screen.name)
            val matchesCategory = selectedCategory == ToolCategory.ALL || tool.category == selectedCategory
            val matchesQuery = searchQuery.isBlank() ||
                    tool.title.contains(searchQuery, ignoreCase = true) ||
                    tool.description.contains(searchQuery, ignoreCase = true)
            matchesFavorite && matchesCategory && matchesQuery
        }

        // Pin favorites to top when not explicitly searching or filtering by favorites only
        if (!showOnlyFavorites && searchQuery.isBlank()) {
            baseList.sortedByDescending { favoriteScreens.contains(it.screen.name) }
        } else {
            baseList
        }
    }

    if (showProDialog) {
        ProUpgradeDialog(
            billingManager = billingManager,
            onDismissRequest = { showProDialog = false }
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding(),
        topBar = {
            TopAppBar(
                modifier = Modifier.fillMaxWidth(),
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.app_banner),
                            contentDescription = "APS Tools Banner Logo",
                            modifier = Modifier
                                .height(38.dp)
                                .width(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(
                            verticalArrangement = Arrangement.spacedBy(1.dp),
                            modifier = Modifier.align(Alignment.CenterVertically)
                        ) {
                            Text(
                                text = "APS TOOLS",
                                fontWeight = FontWeight.Black,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    platformStyle = PlatformTextStyle(includeFontPadding = false)
                                ),
                                letterSpacing = 0.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Simple Tools • Smart Results",
                                fontSize = 11.sp,
                                style = TextStyle(
                                    platformStyle = PlatformTextStyle(includeFontPadding = false)
                                ),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                },
                actions = {
                    // Sleek, minimalist Dark/Light mode icon button (animated Sun/Moon)
                    IconButton(
                        onClick = {
                            HapticUtils.performClick(context)
                            val nextMode = if (isCurrentlyDark) ThemeMode.LIGHT else ThemeMode.DARK
                            preferencesManager.setThemeMode(nextMode)
                        },
                        modifier = Modifier
                            .testTag("theme_toggle_button")
                            .size(40.dp)
                    ) {
                        AnimatedContent(
                            targetState = isCurrentlyDark,
                            transitionSpec = {
                                (fadeIn(animationSpec = tween(220)) + scaleIn(initialScale = 0.75f))
                                    .togetherWith(fadeOut(animationSpec = tween(180)) + scaleOut(targetScale = 0.75f))
                            },
                            label = "theme_mode_switch"
                        ) { inDark ->
                            Icon(
                                imageVector = if (inDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = if (inDark) "Switch to Light Mode" else "Switch to Dark Mode",
                                tint = if (inDark) Color(0xFFFBBF24) else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Far Top-Right: Premium golden "PRO" button (Remove Ads / Subscription)
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = if (isPremium) {
                                        listOf(Color(0xFFFDE68A), Color(0xFFFBBF24))
                                    } else {
                                        listOf(Color(0xFFF59E0B), Color(0xFFD97706))
                                    }
                                )
                            )
                            .clickable {
                                HapticUtils.performClick(context)
                                showProDialog = true
                            }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                            .testTag("open_pro_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.WorkspacePremium,
                                contentDescription = "PRO Subscription",
                                tint = if (isPremium) Color(0xFF78350F) else Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "PRO",
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                letterSpacing = 0.5.sp,
                                color = if (isPremium) Color(0xFF78350F) else Color.White
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            // Sticky Banner Ad at the bottom (hidden for PRO users)
            StickyBannerAd(
                isPremium = isPremium,
                modifier = Modifier.testTag("sticky_banner_ad")
            )
        }
    ) { innerPadding ->
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 320.dp),
            contentPadding = PaddingValues(
                start = 18.dp,
                end = 18.dp,
                top = innerPadding.calculateTopPadding() + 4.dp,
                bottom = innerPadding.calculateBottomPadding() + 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Hero Brand Banner Card
            item(span = { GridItemSpan(maxLineSpan) }) {
                HeroBrandBanner(
                    isPremium = isPremium,
                    onGoProClick = { showProDialog = true }
                )
            }

            // Search Bar Item
            item(span = { GridItemSpan(maxLineSpan) }) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search any tool (e.g. compress, GST, QR)...") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = ApsBlue)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ApsBlue,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dashboard_search_input")
                )
            }

            // Category Filter Tabs
            item(span = { GridItemSpan(maxLineSpan) }) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Quick Favorites Filter Tab
                    item {
                        FilterChip(
                            selected = showOnlyFavorites,
                            onClick = {
                                HapticUtils.performClick(context)
                                showOnlyFavorites = !showOnlyFavorites
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = if (showOnlyFavorites) Color(0xFFD97706) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            label = { Text("Favorites (${favoriteScreens.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFFEF3C7),
                                selectedLabelColor = Color(0xFF92400E)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("filter_favorites_chip")
                        )
                    }

                    items(ToolCategory.values()) { category ->
                        FilterChip(
                            selected = !showOnlyFavorites && selectedCategory == category,
                            onClick = {
                                HapticUtils.performClick(context)
                                showOnlyFavorites = false
                                selectedCategory = category
                            },
                            label = { Text(category.title, fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ApsBlue,
                                selectedLabelColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }

            // Tool Items Count Header
            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 2.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (showOnlyFavorites) "PINNED FAVORITES" else selectedCategory.title.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 1.1.sp
                    )
                    Text(
                        text = "${filteredTools.size} Tools",
                        style = MaterialTheme.typography.labelSmall,
                        color = ApsBlue,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Grid of Tool Cards
            items(filteredTools) { tool ->
                val isFav = favoriteScreens.contains(tool.screen.name)
                DashboardToolCard(
                    tool = tool,
                    isFavorite = isFav,
                    onToggleFavorite = {
                        HapticUtils.performClick(context)
                        preferencesManager.toggleFavorite(tool.screen.name)
                    },
                    onClick = {
                        HapticUtils.performClick(context)
                        onNavigateToTool(tool.screen)
                    }
                )
            }
        }
    }
}

@Composable
private fun HeroBrandBanner(
    isPremium: Boolean,
    onGoProClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF1E3A8A), // Deep Royal Slate Blue
                            Color(0xFF2563EB)  // Vibrant APS Blue
                        )
                    )
                )
                .padding(20.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF67E8F9))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "PRODUCTION UTILITY HUB",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFBAE6FD),
                            letterSpacing = 1.sp
                        )
                    }

                    if (isPremium) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(ProGold)
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "PRO ACTIVE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Simple Tools • Smart Results",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "All-in-one suite for photo compression, PDF conversion, financial computations, and QR utilities running 100% locally.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.85f),
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
private fun DashboardToolCard(
    tool: ToolDefinition,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag(tool.testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Icon Box
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(tool.backgroundColor)
                ) {
                    Icon(
                        imageVector = tool.icon,
                        contentDescription = tool.title,
                        tint = tool.accentColor,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Category Tag
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(tool.backgroundColor)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = tool.category.title.uppercase(),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = tool.accentColor,
                            letterSpacing = 0.6.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Favorite Pin Button
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("pin_favorite_${tool.screen.name}")
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = if (isFavorite) "Remove from favorites" else "Pin to favorites",
                            tint = if (isFavorite) Color(0xFFF59E0B) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = tool.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = tool.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp,
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Launch Tool",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = tool.accentColor
                )

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(tool.backgroundColor)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = tool.accentColor,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
        }
    }
}
