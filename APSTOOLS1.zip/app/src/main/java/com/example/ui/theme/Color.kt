package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// APS Brand: Vibrant Blue & Slate
val ApsBlue = Color(0xFF2563EB)
val ApsBlueDark = Color(0xFF1D4ED8)
val ApsBlueLight = Color(0xFF60A5FA)
val ApsBlueContainer = Color(0xFFEFF6FF)
val ApsOnBlueContainer = Color(0xFF1E3A8A)

// Slate Neutrals
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate500 = Color(0xFF64748B)
val Slate400 = Color(0xFF94A3B8)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

// Secondary Cyan
val SkySecondary = Color(0xFF0284C7)
val SkySecondaryContainer = Color(0xFFE0F2FE)
val SkyOnSecondaryContainer = Color(0xFF075985)

// Category Accents
val CategoryImageBlue = Color(0xFF2563EB)
val CategoryImageBg = Color(0xFFEFF6FF)
val CategoryFinanceGreen = Color(0xFF059669)
val CategoryFinanceBg = Color(0xFFECFDF5)
val CategoryDailyPurple = Color(0xFF7C3AED)
val CategoryDailyBg = Color(0xFFF5F3FF)

// Pro / Premium Gold
val ProGold = Color(0xFFF59E0B)
val ProGoldBg = Color(0xFFFEF3C7)

// Tool Accents
val GstBlue = Color(0xFF2563EB)
val GstBlueBg = Color(0xFFEFF6FF)
val EmiGreen = Color(0xFF0D9488)
val EmiGreenBg = Color(0xFFF0FDFA)
val AgeOrange = Color(0xFFEA580C)
val AgeOrangeBg = Color(0xFFFFF7ED)
val SplitTeal = Color(0xFF0284C7)
val SplitTealBg = Color(0xFFF0F9FF)
val QrIndigo = Color(0xFF4F46E5)
val QrIndigoBg = Color(0xFFEEF2FF)
val NotesSlate = Color(0xFF475569)
val NotesSlateBg = Color(0xFFF1F5F9)
val DiscountPurple = Color(0xFF9333EA)
val DiscountPurpleBg = Color(0xFFFAF5FF)

// Surface & Backgrounds
val SurfaceLight = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OutlineLight = Color(0xFFCBD5E1)
val OnSurfaceLight = Color(0xFF0F172A)
val OnSurfaceVariantLight = Color(0xFF475569)

// Dark Theme tokens
val IndigoDark = Color(0xFF93C5FD)
val IndigoDarkContainer = Color(0xFF1E3A8A)
val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val OutlineDark = Color(0xFF475569)
val OnSurfaceDark = Color(0xFFF8FAFC)
val OnSurfaceVariantDark = Color(0xFF94A3B8)

