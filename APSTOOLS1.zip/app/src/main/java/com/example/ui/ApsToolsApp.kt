package com.example.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.ads.AdManager
import com.example.analytics.AppAnalytics
import com.example.billing.BillingManager
import com.example.model.AppScreen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.example.ui.screens.AgeCalculatorScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DiscountCalculatorScreen
import com.example.ui.screens.GstCalculatorScreen
import com.example.ui.screens.ImageResizerScreen
import com.example.ui.screens.ImageToPdfScreen
import com.example.ui.screens.LoanEmiScreen
import com.example.ui.screens.NotesCounterScreen
import com.example.ui.screens.PhotoCompressorScreen
import com.example.ui.screens.QrToolScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.SplitBillScreen

@Composable
fun ApsToolsApp(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val activity = context as? Activity

    // Initialize Billing and Ads asynchronously so UI thread is never blocked
    val billingManager = remember { BillingManager.getInstance(context) }

    LaunchedEffect(Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                AppAnalytics.initialize(context.applicationContext)
            } catch (e: Throwable) {
                // Background analytics init
            }
            try {
                AdManager.initialize(context.applicationContext)
            } catch (e: Throwable) {
                // Background ads init
            }
            try {
                billingManager.startConnection()
            } catch (e: Throwable) {
                // Background billing setup
            }
        }
    }

    var currentScreen by remember { mutableStateOf(AppScreen.SPLASH) }

    LaunchedEffect(currentScreen) {
        if (currentScreen != AppScreen.SPLASH && currentScreen != AppScreen.DASHBOARD) {
            AppAnalytics.logToolOpened(context, currentScreen.name)
        }
    }

    // Intercept back button when inside a tool screen to return to dashboard
    BackHandler(enabled = currentScreen != AppScreen.DASHBOARD && currentScreen != AppScreen.SPLASH) {
        currentScreen = AppScreen.DASHBOARD
    }

    Surface(modifier = modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = {
                if (initialState == AppScreen.SPLASH) {
                    fadeIn().togetherWith(fadeOut())
                } else if (targetState != AppScreen.DASHBOARD) {
                    (slideInHorizontally { width -> width } + fadeIn()).togetherWith(
                        slideOutHorizontally { width -> -width / 3 } + fadeOut()
                    )
                } else {
                    (slideInHorizontally { width -> -width / 3 } + fadeIn()).togetherWith(
                        slideOutHorizontally { width -> width } + fadeOut()
                    )
                }
            },
            label = "screen_navigation"
        ) { screen ->
            when (screen) {
                AppScreen.SPLASH -> SplashScreen(
                    onSplashFinished = { currentScreen = AppScreen.DASHBOARD }
                )

                AppScreen.DASHBOARD -> DashboardScreen(
                    billingManager = billingManager,
                    onNavigateToTool = { newScreen -> currentScreen = newScreen }
                )

                // Image & Doc Tools
                AppScreen.PHOTO_COMPRESSOR -> PhotoCompressorScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD },
                    billingManager = billingManager
                )
                AppScreen.IMAGE_RESIZER -> ImageResizerScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD },
                    billingManager = billingManager
                )
                AppScreen.IMAGE_TO_PDF -> ImageToPdfScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD },
                    billingManager = billingManager
                )

                // Financial & Utility Tools
                AppScreen.GST_CALCULATOR -> GstCalculatorScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )
                AppScreen.LOAN_EMI_CALCULATOR -> LoanEmiScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )
                AppScreen.AGE_CALCULATOR -> AgeCalculatorScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )
                AppScreen.SPLIT_BILL -> SplitBillScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD },
                    billingManager = billingManager
                )
                AppScreen.DISCOUNT_CALCULATOR -> DiscountCalculatorScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )

                // Daily Quick Tools
                AppScreen.QR_CODE_TOOL -> QrToolScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD },
                    billingManager = billingManager
                )
                AppScreen.NOTES_COUNTER -> NotesCounterScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD },
                    billingManager = billingManager
                )
            }
        }
    }
}

// Backward compatibility alias
@Composable
fun SmartToolKitApp(modifier: Modifier = Modifier) {
    ApsToolsApp(modifier = modifier)
}

@Composable
fun MainDashboardScreen(modifier: Modifier = Modifier) {
    ApsToolsApp(modifier = modifier)
}
