package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.lifecycleScope
import com.example.billing.BillingManager
import com.example.model.AppPreferencesManager
import com.example.model.ThemeMode
import com.example.ui.ApsToolsApp
import com.example.ui.MainDashboardScreen
import com.example.ui.theme.ApsToolsTheme
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    setContent {
      ApsToolsTheme {
        MainDashboardScreen()
      }
    }

    lifecycleScope.launch(Dispatchers.IO) {
      MobileAds.initialize(this@MainActivity) {}
      initBillingClient()
    }
  }

  private fun initBillingClient() {
    try {
      BillingManager.getInstance(applicationContext).startConnection()
    } catch (e: Throwable) {
      // Background non-blocking initialization
    }
  }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
  ApsToolsTheme { MainDashboardScreen() }
}

