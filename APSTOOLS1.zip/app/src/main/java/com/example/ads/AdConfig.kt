package com.example.ads

/**
 * AdMob configuration constants for APS TOOLS.
 * Easily switch between Google official test IDs and production unit IDs.
 */
object AdConfig {
    // AdMob App ID
    const val APP_ID = "ca-app-pub-3063864969990896~7861759208"

    // Banner Ad Unit ID (Sticky Bottom Banner)
    const val BANNER_AD_ID = "ca-app-pub-3063864969990896/9487858185"

    // Interstitial Ad Unit ID (Post-Task Fullscreen Ad)
    const val INTERSTITIAL_AD_ID = "ca-app-pub-3063864969990896/9431570758"

    // Native Ad Unit ID
    const val NATIVE_AD_ID = "ca-app-pub-3063864969990896/4179244074"
}
