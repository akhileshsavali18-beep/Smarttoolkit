package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Indigo
val IndigoPrimary = Color(0xFF4F46E5)
val IndigoPrimaryLight = Color(0xFF818CF8)
val IndigoPrimaryContainer = Color(0xFFEEF2FF)
val IndigoOnPrimaryContainer = Color(0xFF312E81)

// Secondary Cyan / Sky
val SkySecondary = Color(0xFF0284C7)
val SkySecondaryContainer = Color(0xFFE0F2FE)
val SkyOnSecondaryContainer = Color(0xFF075985)

// Tertiary Teal / Emerald
val EmeraldTertiary = Color(0xFF059669)
val EmeraldTertiaryContainer = Color(0xFFD1FAE5)
val EmeraldOnTertiaryContainer = Color(0xFF065F46)

// Accents for specific tools
val GstBlue = Color(0xFF2563EB)
val GstBlueBg = Color(0xFFEFF6FF)
val EmiGreen = Color(0xFF0D9488)
val EmiGreenBg = Color(0xFFF0FDFA)
val AgeOrange = Color(0xFFEA580C)
val AgeOrangeBg = Color(0xFFFFF7ED)
val DiscountPurple = Color(0xFF9333EA)
val DiscountPurpleBg = Color(0xFFFAF5FF)

// Neutral tones
val SurfaceLight = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OutlineLight = Color(0xFFCBD5E1)
val OnSurfaceLight = Color(0xFF0F172A)
val OnSurfaceVariantLight = Color(0xFF475569)

// Dark Theme tokens
val IndigoDark = Color(0xFFA5B4FC)
val IndigoDarkContainer = Color(0xFF3730A3)
val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val OutlineDark = Color(0xFF475569)
val OnSurfaceDark = Color(0xFFF8FAFC)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
