package com.example.model

import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.TimeUnit

enum class AppScreen {
    DASHBOARD,
    GST_CALCULATOR,
    LOAN_EMI_CALCULATOR,
    AGE_CALCULATOR,
    DISCOUNT_CALCULATOR
}

enum class GstMode {
    ADD_GST,
    REMOVE_GST
}

data class GstResult(
    val netAmount: Double = 0.0,
    val cgst: Double = 0.0,
    val sgst: Double = 0.0,
    val totalGst: Double = 0.0,
    val totalAmount: Double = 0.0
)

enum class EmiTenureType {
    YEARS,
    MONTHS
}

data class EmiResult(
    val monthlyEmi: Double = 0.0,
    val totalInterest: Double = 0.0,
    val totalPayment: Double = 0.0,
    val principalPercentage: Float = 100f,
    val interestPercentage: Float = 0f
)

data class AgeResult(
    val years: Int = 0,
    val months: Int = 0,
    val days: Int = 0,
    val daysUntilNextBirthday: Int = 0,
    val nextBirthdayDayOfWeek: String = ""
)

data class DiscountResult(
    val originalPrice: Double = 0.0,
    val discountPercent: Double = 0.0,
    val discountAmount: Double = 0.0,
    val finalPrice: Double = 0.0
)

object Calculators {
    private val currencyFormatter = DecimalFormat("#,##0.00")
    private val intFormatter = DecimalFormat("#,##0")

    fun formatNumber(value: Double): String = currencyFormatter.format(value)
    fun formatInt(value: Long): String = intFormatter.format(value)

    fun calculateGst(amount: Double, ratePercent: Double, mode: GstMode): GstResult {
        if (amount <= 0.0 || ratePercent < 0.0) {
            return GstResult()
        }
        return if (mode == GstMode.ADD_GST) {
            val netAmount = amount
            val totalGst = amount * (ratePercent / 100.0)
            val halfGst = totalGst / 2.0
            val totalAmount = netAmount + totalGst
            GstResult(
                netAmount = netAmount,
                cgst = halfGst,
                sgst = halfGst,
                totalGst = totalGst,
                totalAmount = totalAmount
            )
        } else {
            val totalAmount = amount
            val netAmount = amount / (1.0 + (ratePercent / 100.0))
            val totalGst = totalAmount - netAmount
            val halfGst = totalGst / 2.0
            GstResult(
                netAmount = netAmount,
                cgst = halfGst,
                sgst = halfGst,
                totalGst = totalGst,
                totalAmount = totalAmount
            )
        }
    }

    fun calculateEmi(principal: Double, annualRatePercent: Double, tenureValue: Int, tenureType: EmiTenureType): EmiResult {
        if (principal <= 0.0 || tenureValue <= 0) {
            return EmiResult()
        }
        val totalMonths = if (tenureType == EmiTenureType.YEARS) tenureValue * 12 else tenureValue
        if (totalMonths <= 0) return EmiResult()

        if (annualRatePercent <= 0.0) {
            val emi = principal / totalMonths
            return EmiResult(
                monthlyEmi = emi,
                totalInterest = 0.0,
                totalPayment = principal,
                principalPercentage = 100f,
                interestPercentage = 0f
            )
        }

        val monthlyRate = (annualRatePercent / 12.0) / 100.0
        val factor = Math.pow(1.0 + monthlyRate, totalMonths.toDouble())
        val monthlyEmi = (principal * monthlyRate * factor) / (factor - 1.0)
        val totalPayment = monthlyEmi * totalMonths
        val totalInterest = (totalPayment - principal).coerceAtLeast(0.0)
        val principalPct = ((principal / totalPayment) * 100).toFloat().coerceIn(0f, 100f)
        val interestPct = (100f - principalPct).coerceIn(0f, 100f)

        return EmiResult(
            monthlyEmi = monthlyEmi,
            totalInterest = totalInterest,
            totalPayment = totalPayment,
            principalPercentage = principalPct,
            interestPercentage = interestPct
        )
    }

    fun calculateAge(birthMillis: Long, todayMillis: Long = System.currentTimeMillis()): AgeResult {
        val birthCal = Calendar.getInstance().apply { timeInMillis = birthMillis }
        val todayCal = Calendar.getInstance().apply { timeInMillis = todayMillis }

        if (birthCal.after(todayCal)) {
            return AgeResult()
        }

        val bYear = birthCal.get(Calendar.YEAR)
        val bMonth = birthCal.get(Calendar.MONTH)
        val bDay = birthCal.get(Calendar.DAY_OF_MONTH)

        val tYear = todayCal.get(Calendar.YEAR)
        val tMonth = todayCal.get(Calendar.MONTH)
        val tDay = todayCal.get(Calendar.DAY_OF_MONTH)

        var years = tYear - bYear
        var months = tMonth - bMonth
        var days = tDay - bDay

        if (days < 0) {
            val prevCal = Calendar.getInstance().apply {
                set(Calendar.YEAR, tYear)
                set(Calendar.MONTH, tMonth)
                set(Calendar.DAY_OF_MONTH, 1)
                add(Calendar.DAY_OF_MONTH, -1)
            }
            days += prevCal.get(Calendar.DAY_OF_MONTH)
            months -= 1
        }

        if (months < 0) {
            months += 12
            years -= 1
        }

        // Next birthday calculation
        val nextBirthdayCal = Calendar.getInstance().apply {
            set(Calendar.YEAR, tYear)
            set(Calendar.MONTH, bMonth)
            set(Calendar.DAY_OF_MONTH, bDay)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val todayZero = Calendar.getInstance().apply {
            set(Calendar.YEAR, tYear)
            set(Calendar.MONTH, tMonth)
            set(Calendar.DAY_OF_MONTH, tDay)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (nextBirthdayCal.before(todayZero)) {
            nextBirthdayCal.add(Calendar.YEAR, 1)
        }

        val diffMillis = (nextBirthdayCal.timeInMillis - todayZero.timeInMillis).coerceAtLeast(0L)
        val daysUntil = TimeUnit.MILLISECONDS.toDays(diffMillis).toInt()
        val dayFormat = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault())
        val nextBirthdayStr = dayFormat.format(nextBirthdayCal.time)

        return AgeResult(
            years = years,
            months = months,
            days = days,
            daysUntilNextBirthday = daysUntil,
            nextBirthdayDayOfWeek = nextBirthdayStr
        )
    }

    fun calculateDiscount(originalPrice: Double, discountPercent: Double): DiscountResult {
        if (originalPrice <= 0.0 || discountPercent < 0.0) {
            return DiscountResult()
        }
        val validPercent = discountPercent.coerceIn(0.0, 100.0)
        val amountSaved = originalPrice * (validPercent / 100.0)
        val finalPrice = (originalPrice - amountSaved).coerceAtLeast(0.0)
        return DiscountResult(
            originalPrice = originalPrice,
            discountPercent = validPercent,
            discountAmount = amountSaved,
            finalPrice = finalPrice
        )
    }
}
