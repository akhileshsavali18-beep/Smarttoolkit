package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.model.AppScreen
import com.example.ui.screens.AgeCalculatorScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DiscountCalculatorScreen
import com.example.ui.screens.GstCalculatorScreen
import com.example.ui.screens.LoanEmiScreen

@Composable
fun SmartToolKitApp(modifier: Modifier = Modifier) {
    var currentScreen by remember { mutableStateOf(AppScreen.DASHBOARD) }

    // Intercept back key when on a child tool screen to return to dashboard
    BackHandler(enabled = currentScreen != AppScreen.DASHBOARD) {
        currentScreen = AppScreen.DASHBOARD
    }

    Surface(modifier = modifier.fillMaxSize()) {
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = {
                if (targetState != AppScreen.DASHBOARD) {
                    (slideInHorizontally { width -> width } + fadeIn()).togetherWith(
                        slideOutHorizontally { width -> -width / 3 } + fadeOut()
                    )
                } else {
                    (slideInHorizontally { width -> -width / 3 } + fadeIn()).togetherWith(
                        slideOutHorizontally { width -> width } + fadeOut()
                    )
                }
            },
            label = "screen_navigation"
        ) { screen ->
            when (screen) {
                AppScreen.DASHBOARD -> DashboardScreen(
                    onNavigateToTool = { newScreen -> currentScreen = newScreen }
                )
                AppScreen.GST_CALCULATOR -> GstCalculatorScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )
                AppScreen.LOAN_EMI_CALCULATOR -> LoanEmiScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )
                AppScreen.AGE_CALCULATOR -> AgeCalculatorScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )
                AppScreen.DISCOUNT_CALCULATOR -> DiscountCalculatorScreen(
                    onBack = { currentScreen = AppScreen.DASHBOARD }
                )
            }
        }
    }
}
