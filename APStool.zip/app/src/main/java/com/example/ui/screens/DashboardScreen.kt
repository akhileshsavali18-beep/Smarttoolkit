package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.ads.AdManager
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocalCafe
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SquareFoot
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ads.StickyBannerAd
import com.example.billing.BillingManager
import com.example.model.AppPreferencesManager
import com.example.model.AppScreen
import com.example.model.ThemeMode
import com.example.model.ToolCategory
import com.example.ui.components.ProUpgradeDialog
import com.example.ui.theme.AgeOrange
import com.example.ui.theme.AgeOrangeBg
import com.example.ui.theme.ApsBlue
import com.example.ui.theme.AreaEmerald
import com.example.ui.theme.AreaEmeraldBg
import com.example.ui.theme.AspectRatioBlue
import com.example.ui.theme.AspectRatioBlueBg
import com.example.ui.theme.Base64Slate
import com.example.ui.theme.Base64SlateBg
import com.example.ui.theme.BmiTeal
import com.example.ui.theme.BmiTealBg
import com.example.ui.theme.BodyFatRose
import com.example.ui.theme.BodyFatRoseBg
import com.example.ui.theme.BreathingCyan
import com.example.ui.theme.BreathingCyanBg
import com.example.ui.theme.CategoryImageBg
import com.example.ui.theme.CategoryImageBlue
import com.example.ui.theme.CgpaIndigo
import com.example.ui.theme.CgpaIndigoBg
import com.example.ui.theme.CompassTeal
import com.example.ui.theme.CompassTealBg
import com.example.ui.theme.CountdownIndigo
import com.example.ui.theme.CountdownIndigoBg
import com.example.ui.theme.DataBlue
import com.example.ui.theme.DataBlueBg
import com.example.ui.theme.DayBlue
import com.example.ui.theme.DayBlueBg
import com.example.ui.theme.DeadPixelDark
import com.example.ui.theme.DeadPixelDarkBg
import com.example.ui.theme.DecisionPink
import com.example.ui.theme.DecisionPinkBg
import com.example.ui.theme.DiscountPurple
import com.example.ui.theme.DiscountPurpleBg
import com.example.ui.theme.DuplicateCyan
import com.example.ui.theme.DuplicateCyanBg
import com.example.ui.theme.EmiGreen
import com.example.ui.theme.EmiGreenBg
import com.example.ui.theme.FactorialTeal
import com.example.ui.theme.FactorialTealBg
import com.example.ui.theme.FuelAmber
import com.example.ui.theme.FuelAmberBg
import com.example.ui.theme.GstBlue
import com.example.ui.theme.GstBlueBg
import com.example.ui.theme.HeartRateRed
import com.example.ui.theme.HeartRateRedBg
import com.example.ui.theme.IdealWeightViolet
import com.example.ui.theme.IdealWeightVioletBg
import com.example.ui.theme.InflationRed
import com.example.ui.theme.InflationRedBg
import com.example.ui.theme.InverterViolet
import com.example.ui.theme.InverterVioletBg
import com.example.ui.theme.LeapYearGreen
import com.example.ui.theme.LeapYearGreenBg
import com.example.ui.theme.LevelLime
import com.example.ui.theme.LevelLimeBg
import com.example.ui.theme.MorseCodeAmber
import com.example.ui.theme.MorseCodeAmberBg
import com.example.ui.theme.MultiplyAmber
import com.example.ui.theme.MultiplyAmberBg
import com.example.ui.theme.NotesSlate
import com.example.ui.theme.NotesSlateBg
import com.example.ui.theme.NumberBasePurple
import com.example.ui.theme.NumberBasePurpleBg
import com.example.ui.theme.PercentOrange
import com.example.ui.theme.PercentOrangeBg
import com.example.ui.theme.PrimeGreen
import com.example.ui.theme.PrimeGreenBg
import com.example.ui.theme.ProGold
import com.example.ui.theme.ProGoldBg
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.ProfitGreenBg
import com.example.ui.theme.QrIndigo
import com.example.ui.theme.QrIndigoBg
import com.example.ui.theme.RomanGold
import com.example.ui.theme.RomanGoldBg
import com.example.ui.theme.ScreenLightYellow
import com.example.ui.theme.ScreenLightYellowBg
import com.example.ui.theme.SleepCyclePurple
import com.example.ui.theme.SleepCyclePurpleBg
import com.example.ui.theme.SlugIndigo
import com.example.ui.theme.SlugIndigoBg
import com.example.ui.theme.SoundMeterCyan
import com.example.ui.theme.SoundMeterCyanBg
import com.example.ui.theme.SpeedOrange
import com.example.ui.theme.SpeedOrangeBg
import com.example.ui.theme.SplitTeal
import com.example.ui.theme.SplitTealBg
import com.example.ui.theme.TallyPurple
import com.example.ui.theme.TallyPurpleBg
import com.example.ui.theme.TipEmerald
import com.example.ui.theme.TipEmeraldBg
import com.example.ui.theme.UnitCyan
import com.example.ui.theme.UnitCyanBg
import com.example.ui.theme.UrlTeal
import com.example.ui.theme.UrlTealBg
import com.example.ui.theme.WhiteboardBlue
import com.example.ui.theme.WhiteboardBlueBg
import com.example.ui.theme.WorldClockPurple
import com.example.ui.theme.WorldClockPurpleBg
import com.example.utils.HapticUtils
import java.util.Calendar

data class ToolDefinition(
    val screen: AppScreen,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val category: ToolCategory,
    val accentColor: Color,
    val backgroundColor: Color,
    val testTag: String
)

enum class NavTab(val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    HOME("Home", Icons.Filled.Home, Icons.Outlined.Home),
    CATEGORIES("Categories", Icons.Filled.Category, Icons.Outlined.Category),
    FAVOURITES("Favourites", Icons.Filled.Star, Icons.Outlined.StarBorder),
    PROFILE("Profile", Icons.Filled.Person, Icons.Outlined.Person)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    billingManager: BillingManager,
    onNavigateToTool: (AppScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val preferencesManager = remember { AppPreferencesManager.getInstance(context) }
    val favoriteScreens by preferencesManager.favoriteTools.collectAsState()
    val recentScreenNames by preferencesManager.recentTools.collectAsState()
    val themeMode by preferencesManager.themeMode.collectAsState()
    val isSystemDark = isSystemInDarkTheme()
    val isCurrentlyDark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemDark
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val isPremium by billingManager.isPremium.collectAsState()

    var activeTab by remember { mutableStateOf(NavTab.HOME) }
    var showProDialog by remember { mutableStateOf(false) }
    var showFeedbackDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showCoffeeDialog by remember { mutableStateOf(false) }

    // Search query on Home / Categories
    var searchQuery by remember { mutableStateOf("") }

    val allTools = remember {
        listOf(
            // Category 1: Media & Documents (4 tools)
            ToolDefinition(
                screen = AppScreen.PHOTO_COMPRESSOR,
                title = "Photo Compressor",
                description = "Compress KB/MB file size up to 90% while keeping sharp clarity.",
                icon = Icons.Default.Compress,
                category = ToolCategory.MEDIA_DOC,
                accentColor = CategoryImageBlue,
                backgroundColor = CategoryImageBg,
                testTag = "tool_card_compressor"
            ),
            ToolDefinition(
                screen = AppScreen.IMAGE_RESIZER,
                title = "Image Resizer",
                description = "Custom dimensions, pixels, aspect ratio lock, and quick presets.",
                icon = Icons.Default.AspectRatio,
                category = ToolCategory.MEDIA_DOC,
                accentColor = CategoryImageBlue,
                backgroundColor = CategoryImageBg,
                testTag = "tool_card_resizer"
            ),
            ToolDefinition(
                screen = AppScreen.IMAGE_TO_PDF,
                title = "Image to PDF Converter",
                description = "Multi-image PDF creation with custom quality & A4 sizing.",
                icon = Icons.Default.PictureAsPdf,
                category = ToolCategory.MEDIA_DOC,
                accentColor = CategoryImageBlue,
                backgroundColor = CategoryImageBg,
                testTag = "tool_card_image_to_pdf"
            ),
            ToolDefinition(
                screen = AppScreen.QR_CODE_TOOL,
                title = "QR Code Generator & Scanner",
                description = "Generate crisp custom QR codes and scan instantly from camera or gallery.",
                icon = Icons.Default.QrCode,
                category = ToolCategory.MEDIA_DOC,
                accentColor = QrIndigo,
                backgroundColor = QrIndigoBg,
                testTag = "tool_card_qr"
            ),

            // Category 2: Finance & Shopping (4 tools)
            ToolDefinition(
                screen = AppScreen.GST_CALCULATOR,
                title = "GST Calculator",
                description = "Inclusive and exclusive modes with 5%, 12%, 18%, 28% slabs and CGST/SGST split.",
                icon = Icons.Default.ReceiptLong,
                category = ToolCategory.FINANCE,
                accentColor = GstBlue,
                backgroundColor = GstBlueBg,
                testTag = "tool_card_gst"
            ),
            ToolDefinition(
                screen = AppScreen.LOAN_EMI_CALCULATOR,
                title = "Loan / EMI Calculator",
                description = "Principal, interest rate, and tenure monthly EMI & payment amortization.",
                icon = Icons.Default.AccountBalance,
                category = ToolCategory.FINANCE,
                accentColor = EmiGreen,
                backgroundColor = EmiGreenBg,
                testTag = "tool_card_emi"
            ),
            ToolDefinition(
                screen = AppScreen.DISCOUNT_CALCULATOR,
                title = "Discount Calculator",
                description = "Original price, discount %, and final sale price with savings breakdown.",
                icon = Icons.Default.LocalOffer,
                category = ToolCategory.FINANCE,
                accentColor = DiscountPurple,
                backgroundColor = DiscountPurpleBg,
                testTag = "tool_card_discount"
            ),
            ToolDefinition(
                screen = AppScreen.SPLIT_BILL,
                title = "Bill Splitter & Tip Calculator",
                description = "Split restaurant bills, custom tip %, and round off share per person.",
                icon = Icons.Default.Payments,
                category = ToolCategory.FINANCE,
                accentColor = SplitTeal,
                backgroundColor = SplitTealBg,
                testTag = "tool_card_split_bill"
            ),

            // Category 3: Daily Utilities & Health (4 tools)
            ToolDefinition(
                screen = AppScreen.AGE_CALCULATOR,
                title = "Age Calculator",
                description = "Exact age in years, months, days, and next birthday countdown.",
                icon = Icons.Default.Cake,
                category = ToolCategory.DAILY_HEALTH,
                accentColor = AgeOrange,
                backgroundColor = AgeOrangeBg,
                testTag = "tool_card_age"
            ),
            ToolDefinition(
                screen = AppScreen.BMI_CALCULATOR,
                title = "BMI & Health Metric Calculator",
                description = "Height and weight BMI status, category gauge, and ideal weight range.",
                icon = Icons.Default.FitnessCenter,
                category = ToolCategory.DAILY_HEALTH,
                accentColor = BmiTeal,
                backgroundColor = BmiTealBg,
                testTag = "tool_card_bmi"
            ),
            ToolDefinition(
                screen = AppScreen.UNIT_CONVERTER,
                title = "Unit Converter",
                description = "Convert Length, Weight, and Temperature units with multi-unit breakdown.",
                icon = Icons.Default.Straighten,
                category = ToolCategory.DAILY_HEALTH,
                accentColor = UnitCyan,
                backgroundColor = UnitCyanBg,
                testTag = "tool_card_unit_converter"
            ),
            ToolDefinition(
                screen = AppScreen.TALLY_COUNTER,
                title = "Digital Tally Counter",
                description = "Vibration tap count, customizable increments, and reset controls.",
                icon = Icons.Default.TouchApp,
                category = ToolCategory.DAILY_HEALTH,
                accentColor = TallyPurple,
                backgroundColor = TallyPurpleBg,
                testTag = "tool_card_tally"
            ),

            // Batch 2: Finance & Math (4 tools)
            ToolDefinition(
                screen = AppScreen.PERCENTAGE_CALCULATOR,
                title = "Percentage Calculator",
                description = "Quick % of value, increase/decrease %, and ratio percentage calculator.",
                icon = Icons.Default.Percent,
                category = ToolCategory.FINANCE,
                accentColor = PercentOrange,
                backgroundColor = PercentOrangeBg,
                testTag = "tool_card_percentage"
            ),
            ToolDefinition(
                screen = AppScreen.PROFIT_LOSS_CALCULATOR,
                title = "Profit & Loss Calculator",
                description = "Cost price, selling price, margin %, profit/loss breakdown with tax option.",
                icon = Icons.Default.TrendingUp,
                category = ToolCategory.FINANCE,
                accentColor = ProfitGreen,
                backgroundColor = ProfitGreenBg,
                testTag = "tool_card_profit_loss"
            ),
            ToolDefinition(
                screen = AppScreen.CGPA_PERCENTAGE_CALCULATOR,
                title = "CGPA to Percentage Calculator",
                description = "Convert GPA/CGPA to percentage with custom university formula multiplier.",
                icon = Icons.Default.School,
                category = ToolCategory.FINANCE,
                accentColor = CgpaIndigo,
                backgroundColor = CgpaIndigoBg,
                testTag = "tool_card_cgpa"
            ),
            ToolDefinition(
                screen = AppScreen.FUEL_COST_PLANNER,
                title = "Fuel Cost & Mileage Planner",
                description = "Trip distance, fuel mileage economy, total liters and passenger split cost.",
                icon = Icons.Default.LocalGasStation,
                category = ToolCategory.FINANCE,
                accentColor = FuelAmber,
                backgroundColor = FuelAmberBg,
                testTag = "tool_card_fuel_cost"
            ),

            // Batch 2: Daily Utilities & Device Sensors (4 tools)
            ToolDefinition(
                screen = AppScreen.COMPASS_TOOL,
                title = "Compass & Direction Finder",
                description = "Precise magnetic azimuth heading dial, cardinal directions and sensor readout.",
                icon = Icons.Default.Explore,
                category = ToolCategory.DAILY_HEALTH,
                accentColor = CompassTeal,
                backgroundColor = CompassTealBg,
                testTag = "tool_card_compass"
            ),
            ToolDefinition(
                screen = AppScreen.BUBBLE_LEVEL,
                title = "Bubble Level (Spirit Level)",
                description = "Dual-axis accelerometer surface tilt level with calibration & haptic lock.",
                icon = Icons.Default.Speed,
                category = ToolCategory.DAILY_HEALTH,
                accentColor = LevelLime,
                backgroundColor = LevelLimeBg,
                testTag = "tool_card_bubble_level"
            ),
            ToolDefinition(
                screen = AppScreen.DAY_FINDER,
                title = "Day Finder",
                description = "Pick any past or future date for exact day of week, leap year & facts.",
                icon = Icons.Default.Event,
                category = ToolCategory.DAILY_HEALTH,
                accentColor = DayBlue,
                backgroundColor = DayBlueBg,
                testTag = "tool_card_day_finder"
            ),
            ToolDefinition(
                screen = AppScreen.WORLD_CLOCK,
                title = "World Clock / Timezone Difference",
                description = "Interactive timezone slider, global cities comparison, and day/night clocks.",
                icon = Icons.Default.Public,
                category = ToolCategory.DAILY_HEALTH,
                accentColor = WorldClockPurple,
                backgroundColor = WorldClockPurpleBg,
                testTag = "tool_card_world_clock"
            ),

            // Batch 2: Health & Fitness (4 tools)
            ToolDefinition(
                screen = AppScreen.IDEAL_BODY_WEIGHT,
                title = "Ideal Body Weight Calculator",
                description = "Devine, Robinson, and Miller clinical formulas by gender and body frame.",
                icon = Icons.Default.FitnessCenter,
                category = ToolCategory.HEALTH_FITNESS,
                accentColor = IdealWeightViolet,
                backgroundColor = IdealWeightVioletBg,
                testTag = "tool_card_ideal_weight"
            ),
            ToolDefinition(
                screen = AppScreen.BODY_FAT_ESTIMATOR,
                title = "Body Fat Percentage Estimator",
                description = "U.S. Navy circumference standard calculation with lean vs fat mass breakdown.",
                icon = Icons.Default.MonitorWeight,
                category = ToolCategory.HEALTH_FITNESS,
                accentColor = BodyFatRose,
                backgroundColor = BodyFatRoseBg,
                testTag = "tool_card_body_fat"
            ),
            ToolDefinition(
                screen = AppScreen.BREATHING_EXERCISE,
                title = "Breathing Exercise Guide",
                description = "Pulsating visual guide for 4-7-8 relaxation and stress-relief rhythm.",
                icon = Icons.Default.Air,
                category = ToolCategory.HEALTH_FITNESS,
                accentColor = BreathingCyan,
                backgroundColor = BreathingCyanBg,
                testTag = "tool_card_breathing"
            ),
            ToolDefinition(
                screen = AppScreen.HEART_RATE_ZONES,
                title = "Target Heart Rate Zones",
                description = "5 cardio training intensity zones, Tanaka formula, and maximum heart rate.",
                icon = Icons.Default.Favorite,
                category = ToolCategory.HEALTH_FITNESS,
                accentColor = HeartRateRed,
                backgroundColor = HeartRateRedBg,
                testTag = "tool_card_heart_rate"
            ),

            // Batch 2: Science & Converters (3 tools)
            ToolDefinition(
                screen = AppScreen.AREA_CONVERTER,
                title = "Area & Land Converter",
                description = "Sq ft, sq m, acres, guntha, hectares, bigha, and full unit breakdown.",
                icon = Icons.Default.SquareFoot,
                category = ToolCategory.SCIENCE_CONVERTERS,
                accentColor = AreaEmerald,
                backgroundColor = AreaEmeraldBg,
                testTag = "tool_card_area_converter"
            ),
            ToolDefinition(
                screen = AppScreen.DATA_STORAGE_CONVERTER,
                title = "Data & Storage Converter",
                description = "Binary (1024) vs Decimal (1000) storage conversion and download speed estimator.",
                icon = Icons.Default.SdStorage,
                category = ToolCategory.SCIENCE_CONVERTERS,
                accentColor = DataBlue,
                backgroundColor = DataBlueBg,
                testTag = "tool_card_data_converter"
            ),
            ToolDefinition(
                screen = AppScreen.ROMAN_NUMERAL_CONVERTER,
                title = "Roman Numeral Converter",
                description = "Bi-directional numbers to Roman numerals conversion with quick keypad.",
                icon = Icons.Default.FormatListNumbered,
                category = ToolCategory.SCIENCE_CONVERTERS,
                accentColor = RomanGold,
                backgroundColor = RomanGoldBg,
                testTag = "tool_card_roman_numerals"
            ),

            // Cash Notes Counter
            ToolDefinition(
                screen = AppScreen.NOTES_COUNTER,
                title = "Cash Denomination Counter",
                description = "Count Indian currency notes (₹2000 to ₹10) with instant total and verbal words.",
                icon = Icons.Default.Notes,
                category = ToolCategory.FINANCE,
                accentColor = NotesSlate,
                backgroundColor = NotesSlateBg,
                testTag = "tool_card_notes_counter"
            ),

            // Batch 3: Text & Developer Utilities (4 tools)
            ToolDefinition(
                screen = AppScreen.BASE64_TOOL,
                title = "Base64 Encoder / Decoder",
                description = "Convert plain text to Base64 and decode Base64 back to plain text offline.",
                icon = Icons.Default.Code,
                category = ToolCategory.MEDIA_DOC,
                accentColor = Base64Slate,
                backgroundColor = Base64SlateBg,
                testTag = "tool_card_base64"
            ),
            ToolDefinition(
                screen = AppScreen.URL_ENCODER_TOOL,
                title = "URL Encoder / Decoder",
                description = "Encode URLs to safe query percent-encoding and decode back with parameter breakdown.",
                icon = Icons.Default.Link,
                category = ToolCategory.MEDIA_DOC,
                accentColor = UrlTeal,
                backgroundColor = UrlTealBg,
                testTag = "tool_card_url_encoder"
            ),
            ToolDefinition(
                screen = AppScreen.NUMBER_BASE_CONVERTER,
                title = "Number Base Converter",
                description = "Convert numbers dynamically across Binary (2), Octal (8), Decimal (10), and Hex (16).",
                icon = Icons.Default.Memory,
                category = ToolCategory.MEDIA_DOC,
                accentColor = NumberBasePurple,
                backgroundColor = NumberBasePurpleBg,
                testTag = "tool_card_number_base"
            ),
            ToolDefinition(
                screen = AppScreen.MORSE_CODE_TOOL,
                title = "Morse Code Converter",
                description = "Convert alphanumeric text to international Morse code dots/dashes with audio/vibration pulse.",
                icon = Icons.Default.GraphicEq,
                category = ToolCategory.MEDIA_DOC,
                accentColor = MorseCodeAmber,
                backgroundColor = MorseCodeAmberBg,
                testTag = "tool_card_morse_code"
            ),

            // Batch 3: Daily Utilities & Decision Makers (4 tools)
            ToolDefinition(
                screen = AppScreen.DECISION_MAKER,
                title = "Decision Maker & Choice Picker",
                description = "Enter options separated by commas or lines, tap to pick a random choice with animated selector.",
                icon = Icons.Default.Casino,
                category = ToolCategory.DAILY_UTILITIES,
                accentColor = DecisionPink,
                backgroundColor = DecisionPinkBg,
                testTag = "tool_card_decision_maker"
            ),
            ToolDefinition(
                screen = AppScreen.EVENT_COUNTDOWN,
                title = "Event Countdown Timer",
                description = "Pick an event title and target future date to show live ticking days, hours, and minutes remaining.",
                icon = Icons.Default.HourglassTop,
                category = ToolCategory.DAILY_UTILITIES,
                accentColor = CountdownIndigo,
                backgroundColor = CountdownIndigoBg,
                testTag = "tool_card_event_countdown"
            ),
            ToolDefinition(
                screen = AppScreen.SCREEN_LIGHT,
                title = "Screen Ambient Color Light",
                description = "Fullscreen night light with warm white, amber, calm blue, red and brightness slider.",
                icon = Icons.Default.ColorLens,
                category = ToolCategory.DAILY_UTILITIES,
                accentColor = ScreenLightYellow,
                backgroundColor = ScreenLightYellowBg,
                testTag = "tool_card_screen_light"
            ),
            ToolDefinition(
                screen = AppScreen.SOUND_METER,
                title = "Sound Level Decibel Meter",
                description = "Clean decibel meter display showing approximate ambient noise level with quiet/moderate/loud gauge.",
                icon = Icons.Default.GraphicEq,
                category = ToolCategory.DAILY_UTILITIES,
                accentColor = SoundMeterCyan,
                backgroundColor = SoundMeterCyanBg,
                testTag = "tool_card_sound_meter"
            ),

            // Batch 3: Math & Academic Utilities (4 tools)
            ToolDefinition(
                screen = AppScreen.PRIME_FACTOR_FINDER,
                title = "Prime Number & Factor Finder",
                description = "Enter any integer to instantly check primality, view prime factorization, and all divisors.",
                icon = Icons.Default.Calculate,
                category = ToolCategory.FINANCE,
                accentColor = PrimeGreen,
                backgroundColor = PrimeGreenBg,
                testTag = "tool_card_prime_factor"
            ),
            ToolDefinition(
                screen = AppScreen.SPEED_CONVERTER,
                title = "Speed & Velocity Converter",
                description = "Real-time conversion across km/h, mph, m/s, knots, ft/s, and Mach speed.",
                icon = Icons.Default.Speed,
                category = ToolCategory.SCIENCE_CONVERTERS,
                accentColor = SpeedOrange,
                backgroundColor = SpeedOrangeBg,
                testTag = "tool_card_speed_converter"
            ),
            ToolDefinition(
                screen = AppScreen.INFLATION_CALCULATOR,
                title = "Inflation & Purchasing Power",
                description = "Current cost, annual inflation rate %, and years to compute future price and purchasing loss.",
                icon = Icons.Default.TrendingUp,
                category = ToolCategory.FINANCE,
                accentColor = InflationRed,
                backgroundColor = InflationRedBg,
                testTag = "tool_card_inflation_calc"
            ),
            ToolDefinition(
                screen = AppScreen.TIP_CALCULATOR,
                title = "Simple Tip & Round-Up Calculator",
                description = "Bill amount, tip slider (%), split count, and one-tap round-up total calculation.",
                icon = Icons.Default.Payments,
                category = ToolCategory.FINANCE,
                accentColor = TipEmerald,
                backgroundColor = TipEmeraldBg,
                testTag = "tool_card_tip_calculator"
            ),

            // Batch 4: Text & Utility (Media & Documents) (3 tools)
            ToolDefinition(
                screen = AppScreen.REVERSE_TEXT_TOOL,
                title = "Reverse Text & Inverter",
                description = "Flip characters backwards, reverse word order, or generate upside-down text.",
                icon = Icons.Default.SwapVert,
                category = ToolCategory.MEDIA_DOC,
                accentColor = InverterViolet,
                backgroundColor = InverterVioletBg,
                testTag = "tool_card_reverse_text"
            ),
            ToolDefinition(
                screen = AppScreen.DUPLICATE_LINE_REMOVER,
                title = "Duplicate Line / Word Remover",
                description = "Clean duplicate items, repetitive lists, and words with case and whitespace trimming.",
                icon = Icons.Default.DeleteSweep,
                category = ToolCategory.MEDIA_DOC,
                accentColor = DuplicateCyan,
                backgroundColor = DuplicateCyanBg,
                testTag = "tool_card_duplicate_remover"
            ),
            ToolDefinition(
                screen = AppScreen.URL_SLUG_GENERATOR,
                title = "Text to URL Slug Generator",
                description = "Convert blog titles and sentences into clean kebab-case or snake_case URL slugs.",
                icon = Icons.Default.Link,
                category = ToolCategory.MEDIA_DOC,
                accentColor = SlugIndigo,
                backgroundColor = SlugIndigoBg,
                testTag = "tool_card_url_slug"
            ),

            // Batch 4: Math & Daily Utility (Finance & Shopping) (3 tools)
            ToolDefinition(
                screen = AppScreen.ASPECT_RATIO_CALCULATOR,
                title = "Aspect Ratio Calculator",
                description = "Calculate aspect ratios for 16:9, 4:3, 1:1, 9:16 and scale custom image resolutions.",
                icon = Icons.Default.AspectRatio,
                category = ToolCategory.FINANCE,
                accentColor = AspectRatioBlue,
                backgroundColor = AspectRatioBlueBg,
                testTag = "tool_card_aspect_ratio"
            ),
            ToolDefinition(
                screen = AppScreen.MULTIPLICATION_TABLE,
                title = "Multiplication Table Generator",
                description = "Instant times tables for any number 1-100 up to ×30 with one-tap copy.",
                icon = Icons.Default.Calculate,
                category = ToolCategory.FINANCE,
                accentColor = MultiplyAmber,
                backgroundColor = MultiplyAmberBg,
                testTag = "tool_card_multiplication_table"
            ),
            ToolDefinition(
                screen = AppScreen.FACTORIAL_EVEN_ODD,
                title = "Factorial & Even/Odd Checker",
                description = "Instant parity check (even/odd) and fast n! computation with exact digit count.",
                icon = Icons.Default.Calculate,
                category = ToolCategory.FINANCE,
                accentColor = FactorialTeal,
                backgroundColor = FactorialTealBg,
                testTag = "tool_card_factorial_even_odd"
            ),

            // Batch 4: Daily Utilities & Sensors (Daily Utilities) (3 tools)
            ToolDefinition(
                screen = AppScreen.LEAP_YEAR_CHECKER,
                title = "Leap Year Checker",
                description = "Check whether any year is a leap year with rule details (400, 100, 4 divisibility).",
                icon = Icons.Default.Event,
                category = ToolCategory.DAILY_UTILITIES,
                accentColor = LeapYearGreen,
                backgroundColor = LeapYearGreenBg,
                testTag = "tool_card_leap_year"
            ),
            ToolDefinition(
                screen = AppScreen.DEAD_PIXEL_TESTER,
                title = "Screen Dead-Pixel & Color Tester",
                description = "Fullscreen pure Red, Green, Blue, White, and Black test tiles for display defect inspection.",
                icon = Icons.Default.Tv,
                category = ToolCategory.DAILY_UTILITIES,
                accentColor = DeadPixelDark,
                backgroundColor = DeadPixelDarkBg,
                testTag = "tool_card_dead_pixel"
            ),
            ToolDefinition(
                screen = AppScreen.SLEEP_CYCLE_CALCULATOR,
                title = "Sleep Cycle Calculator",
                description = "Calculates optimal bedtimes and wake-up times based on 90-minute REM sleep cycles.",
                icon = Icons.Default.Bedtime,
                category = ToolCategory.DAILY_UTILITIES,
                accentColor = SleepCyclePurple,
                backgroundColor = SleepCyclePurpleBg,
                testTag = "tool_card_sleep_cycle"
            ),
            ToolDefinition(
                screen = AppScreen.WHITEBOARD_SIGNATURE_PAD,
                title = "Simple Whiteboard / Quick Signature Pad",
                description = "Smooth canvas sketching, finger signature creator, undo/redo, and direct PNG export.",
                icon = Icons.Default.Brush,
                category = ToolCategory.MEDIA_DOC,
                accentColor = WhiteboardBlue,
                backgroundColor = WhiteboardBlueBg,
                testTag = "tool_card_whiteboard"
            )
        )
    }

    // Tool of the Day (dynamically rotates daily)
    val toolOfTheDay = remember(allTools) {
        val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        allTools[day % allTools.size]
    }

    // Resolve recent tool definitions
    val recentTools = remember(recentScreenNames, allTools) {
        recentScreenNames.mapNotNull { name -> allTools.find { it.screen.name == name } }
    }

    // Favorite tool definitions
    val favoriteTools = remember(favoriteScreens, allTools) {
        allTools.filter { favoriteScreens.contains(it.screen.name) }
    }

    fun shareAppAction() {
        HapticUtils.performClick(context)
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(
                Intent.EXTRA_TEXT,
                "Check out APS TOOLS - The ultimate all-in-one offline utility app! Compress photos, convert PDF, compute GST, loan EMI, BMI, Unit Converter, and more.\n\nDownload on Google Play: https://play.google.com/store/apps/details?id=${context.packageName}"
            )
            type = "text/plain"
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share APS Tools"))
    }

    fun rateAppAction() {
        HapticUtils.performClick(context)
        val pkg = context.packageName
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")))
        } catch (_: Exception) {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")))
        }
    }

    if (showProDialog) {
        ProUpgradeDialog(
            billingManager = billingManager,
            onDismissRequest = { showProDialog = false }
        )
    }

    if (showFeedbackDialog) {
        InAppFeedbackDialog(
            onDismiss = { showFeedbackDialog = false },
            onSubmit = { rating, comment ->
                showFeedbackDialog = false
                HapticUtils.performSuccess(context)
                try {
                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                        data = Uri.parse("mailto:akhileshsworks@gmail.com")
                        putExtra(Intent.EXTRA_SUBJECT, "APS Tools Feedback ($rating★)")
                        putExtra(Intent.EXTRA_TEXT, "Rating: $rating / 5\n\nFeedback:\n$comment")
                    }
                    context.startActivity(Intent.createChooser(intent, "Send Feedback via Email"))
                } catch (e: Exception) {
                    Toast.makeText(context, "Thank you for your $rating★ feedback!", Toast.LENGTH_LONG).show()
                }
            }
        )
    }

    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Privacy Policy", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    text = "APS TOOLS operates 100% offline on your device.\n\n" +
                            "• No personal data, photos, documents, or calculations are ever uploaded to any cloud server.\n" +
                            "• Camera and storage access are used exclusively on-device for QR scanning and saving your converted files to gallery.\n" +
                            "• All features remain fast, private, and secure.",
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { showPrivacyDialog = false }) {
                    Text("Close", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    if (showCoffeeDialog) {
        AlertDialog(
            onDismissRequest = { showCoffeeDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocalCafe, contentDescription = null, tint = Color(0xFFD97706))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Support Akhilesh Systems ☕", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Thank you for supporting independent open development of APS Tools by Akhilesh Systems!\n\nChoose a support option below:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Option A: Watch Rewarded Ad
                    Button(
                        onClick = {
                            showCoffeeDialog = false
                            val activity = context as? Activity
                            if (activity != null) {
                                if (AdManager.isRewardedAdReady()) {
                                    AdManager.showRewardedAd(
                                        activity = activity,
                                        onUserEarnedReward = { amount, type ->
                                            Toast.makeText(context, "Thank you! Rewarded $amount $type for supporting developer.", Toast.LENGTH_LONG).show()
                                        },
                                        onAdDismissed = {
                                            AdManager.loadRewardedAd(activity)
                                        },
                                        onAdFailed = { err ->
                                            Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                } else {
                                    Toast.makeText(context, "Rewarded video ad is loading. Please try again in 3 seconds!", Toast.LENGTH_SHORT).show()
                                    AdManager.loadRewardedAd(activity)
                                }
                            } else {
                                Toast.makeText(context, "Thank you for supporting Akhilesh Systems!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ApsBlue),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.WorkspacePremium, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Watch Short Video Ad", fontWeight = FontWeight.Bold)
                    }

                    // Option B: Official Website Link
                    Button(
                        onClick = {
                            showCoffeeDialog = false
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://akhileshsavali18-beep.github.io/Smarttoolkit/donate.html"))
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Unable to open official website", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ApsBlue),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.Start) {
                            Text("Visit Official Website", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Explore project updates and connect with Akhilesh Systems", fontSize = 10.sp, color = Color.White.copy(alpha = 0.85f))
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showCoffeeDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding(),
        topBar = {
            TopAppBar(
                modifier = Modifier.fillMaxWidth(),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.app_banner),
                            contentDescription = "APS Tools Banner Logo",
                            modifier = Modifier
                                .height(38.dp)
                                .width(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(
                            verticalArrangement = Arrangement.spacedBy(1.dp),
                            modifier = Modifier.align(Alignment.CenterVertically)
                        ) {
                            Text(
                                text = "APS TOOLS",
                                fontWeight = FontWeight.Black,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    platformStyle = PlatformTextStyle(includeFontPadding = false)
                                ),
                                letterSpacing = 0.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Simple Tools • Smart Results",
                                fontSize = 11.sp,
                                style = TextStyle(
                                    platformStyle = PlatformTextStyle(includeFontPadding = false)
                                ),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                },
                actions = {
                    // Dark / Light Mode Switch
                    IconButton(
                        onClick = {
                            HapticUtils.performClick(context)
                            val nextMode = if (isCurrentlyDark) ThemeMode.LIGHT else ThemeMode.DARK
                            preferencesManager.setThemeMode(nextMode)
                        },
                        modifier = Modifier
                            .testTag("theme_toggle_button")
                            .size(40.dp)
                    ) {
                        AnimatedContent(
                            targetState = isCurrentlyDark,
                            transitionSpec = {
                                (fadeIn(animationSpec = tween(220)) + scaleIn(initialScale = 0.75f))
                                    .togetherWith(fadeOut(animationSpec = tween(180)) + scaleOut(targetScale = 0.75f))
                            },
                            label = "theme_mode_switch"
                        ) { inDark ->
                            Icon(
                                imageVector = if (inDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = if (inDark) "Switch to Light Mode" else "Switch to Dark Mode",
                                tint = if (inDark) Color(0xFFFBBF24) else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // PRO Subscription Button
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = if (isPremium) {
                                        listOf(Color(0xFFFDE68A), Color(0xFFFBBF24))
                                    } else {
                                        listOf(Color(0xFFF59E0B), Color(0xFFD97706))
                                    }
                                )
                            )
                            .clickable {
                                HapticUtils.performClick(context)
                                showProDialog = true
                            }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                            .testTag("open_pro_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.WorkspacePremium,
                                contentDescription = "PRO Subscription",
                                tint = if (isPremium) Color(0xFF78350F) else Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isPremium) "PRO" else "GO PRO",
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                letterSpacing = 0.5.sp,
                                color = if (isPremium) Color(0xFF78350F) else Color.White
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Sticky Banner Ad (hidden for PRO users)
                StickyBannerAd(
                    isPremium = isPremium,
                    modifier = Modifier.testTag("sticky_banner_ad")
                )

                // Modern 4-Tab Bottom Navigation Bar
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    NavTab.values().forEach { tab ->
                        val isSelected = activeTab == tab
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                HapticUtils.performClick(context)
                                activeTab = tab
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.title,
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = tab.title,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 11.sp
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ApsBlue,
                                selectedTextColor = ApsBlue,
                                indicatorColor = ApsBlue.copy(alpha = 0.12f),
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.testTag("bottom_nav_${tab.name.lowercase()}")
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (activeTab == NavTab.HOME) {
                ExtendedFloatingActionButton(
                    onClick = { shareAppAction() },
                    icon = { Icon(Icons.Default.Share, contentDescription = "Share App") },
                    text = { Text("Share App", fontWeight = FontWeight.Bold) },
                    containerColor = ApsBlue,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.testTag("floating_share_button")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                NavTab.HOME -> HomeTabContent(
                    allTools = allTools,
                    toolOfTheDay = toolOfTheDay,
                    recentTools = recentTools,
                    favoriteScreens = favoriteScreens,
                    searchQuery = searchQuery,
                    onSearchQueryChange = { searchQuery = it },
                    onToggleFavorite = { screenName ->
                        HapticUtils.performClick(context)
                        preferencesManager.toggleFavorite(screenName)
                    },
                    onNavigateToTool = onNavigateToTool,
                    onExploreCategories = { activeTab = NavTab.CATEGORIES }
                )

                NavTab.CATEGORIES -> CategoriesTabContent(
                    allTools = allTools,
                    favoriteScreens = favoriteScreens,
                    onToggleFavorite = { screenName ->
                        HapticUtils.performClick(context)
                        preferencesManager.toggleFavorite(screenName)
                    },
                    onNavigateToTool = onNavigateToTool
                )

                NavTab.FAVOURITES -> FavoritesTabContent(
                    favoriteTools = favoriteTools,
                    onToggleFavorite = { screenName ->
                        HapticUtils.performClick(context)
                        preferencesManager.toggleFavorite(screenName)
                    },
                    onNavigateToTool = onNavigateToTool,
                    onBrowseTools = { activeTab = NavTab.CATEGORIES }
                )

                NavTab.PROFILE -> ProfileTabContent(
                    isPremium = isPremium,
                    themeMode = themeMode,
                    onSetThemeMode = { mode ->
                        HapticUtils.performClick(context)
                        preferencesManager.setThemeMode(mode)
                    },
                    onGoPro = {
                        HapticUtils.performClick(context)
                        showProDialog = true
                    },
                    onShareApp = { shareAppAction() },
                    onRateUs = { rateAppAction() },
                    onPrivacyPolicy = {
                        HapticUtils.performClick(context)
                        showPrivacyDialog = true
                    },
                    onBuyCoffee = {
                        HapticUtils.performClick(context)
                        showCoffeeDialog = true
                    },
                    onFeedback = {
                        HapticUtils.performClick(context)
                        showFeedbackDialog = true
                    }
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------------------
// TAB 1: HOME TAB CONTENT
// -----------------------------------------------------------------------------------------
@Composable
private fun HomeTabContent(
    allTools: List<ToolDefinition>,
    toolOfTheDay: ToolDefinition,
    recentTools: List<ToolDefinition>,
    favoriteScreens: Set<String>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onNavigateToTool: (AppScreen) -> Unit,
    onExploreCategories: () -> Unit
) {
    val context = LocalContext.current

    val searchFilteredTools = remember(searchQuery, allTools) {
        if (searchQuery.isBlank()) {
            emptyList()
        } else {
            allTools.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                        it.description.contains(searchQuery, ignoreCase = true) ||
                        it.category.title.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 10.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text("Search tools (e.g. compress, BMI, GST, QR)...") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = ApsBlue)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear Search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ApsBlue,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_search_bar")
            )
        }

        // If actively searching, show search results
        if (searchQuery.isNotBlank()) {
            item {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "SEARCH RESULTS (${searchFilteredTools.size})",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 1.sp
                    )
                }
            }

            if (searchFilteredTools.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp)
                        ) {
                            Text(
                                text = "No matching tools found",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Try searching with keywords like photo, pdf, emi, age, bmi, or unit.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(searchFilteredTools) { tool ->
                    val isFav = favoriteScreens.contains(tool.screen.name)
                    DashboardToolCard(
                        tool = tool,
                        isFavorite = isFav,
                        onToggleFavorite = { onToggleFavorite(tool.screen.name) },
                        onClick = {
                            HapticUtils.performClick(context)
                            onNavigateToTool(tool.screen)
                        }
                    )
                }
            }
        } else {
            // Tool of the Day Banner Card
            item {
                ToolOfTheDayCard(
                    tool = toolOfTheDay,
                    onOpen = {
                        HapticUtils.performClick(context)
                        onNavigateToTool(toolOfTheDay.screen)
                    }
                )
            }

            // Recent Tools Section (if any have been used)
            if (recentTools.isNotEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "RECENT TOOLS",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                letterSpacing = 1.sp
                            )
                        }

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(recentTools.take(6)) { tool ->
                                RecentToolChipCard(
                                    tool = tool,
                                    onClick = {
                                        HapticUtils.performClick(context)
                                        onNavigateToTool(tool.screen)
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Quick Access Grid Section (Top 6 tools)
            item {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "QUICK ACCESS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 1.sp
                    )
                    TextButton(onClick = onExploreCategories) {
                        Text("View All (${allTools.size})", fontSize = 12.sp, color = ApsBlue, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // 6 Top Tools Cards
            items(allTools.take(6)) { tool ->
                val isFav = favoriteScreens.contains(tool.screen.name)
                DashboardToolCard(
                    tool = tool,
                    isFavorite = isFav,
                    onToggleFavorite = { onToggleFavorite(tool.screen.name) },
                    onClick = {
                        HapticUtils.performClick(context)
                        onNavigateToTool(tool.screen)
                    }
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------------------
// TAB 2: CATEGORIES TAB CONTENT
// -----------------------------------------------------------------------------------------
@Composable
private fun CategoriesTabContent(
    allTools: List<ToolDefinition>,
    favoriteScreens: Set<String>,
    onToggleFavorite: (String) -> Unit,
    onNavigateToTool: (AppScreen) -> Unit
) {
    val context = LocalContext.current
    val categories = remember {
        listOf(
            ToolCategory.MEDIA_DOC,
            ToolCategory.FINANCE,
            ToolCategory.DAILY_HEALTH,
            ToolCategory.HEALTH_FITNESS,
            ToolCategory.SCIENCE_CONVERTERS
        )
    }
    var selectedCategoryFilter by remember { mutableStateOf(ToolCategory.ALL) }

    val displayedTools = remember(selectedCategoryFilter, allTools) {
        if (selectedCategoryFilter == ToolCategory.ALL) {
            allTools
        } else {
            allTools.filter { it.category == selectedCategoryFilter }
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Filter Chips Bar
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedCategoryFilter == ToolCategory.ALL,
                        onClick = {
                            HapticUtils.performClick(context)
                            selectedCategoryFilter = ToolCategory.ALL
                        },
                        label = { Text("All Categories", fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ApsBlue,
                            selectedLabelColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategoryFilter == cat,
                        onClick = {
                            HapticUtils.performClick(context)
                            selectedCategoryFilter = cat
                        },
                        label = { Text(cat.title, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ApsBlue,
                            selectedLabelColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }

        // Sectioned or Filtered Display
        if (selectedCategoryFilter != ToolCategory.ALL) {
            item {
                Text(
                    text = "${selectedCategoryFilter.title.uppercase()} (${displayedTools.size})",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            }

            items(displayedTools) { tool ->
                val isFav = favoriteScreens.contains(tool.screen.name)
                DashboardToolCard(
                    tool = tool,
                    isFavorite = isFav,
                    onToggleFavorite = { onToggleFavorite(tool.screen.name) },
                    onClick = {
                        HapticUtils.performClick(context)
                        onNavigateToTool(tool.screen)
                    }
                )
            }
        } else {
            item {
                Text(
                    text = "ALL TOOLS (${allTools.size})",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            }

            // Grouped By Categories without inner banner card
            categories.forEach { cat ->
                val groupTools = allTools.filter { it.category == cat }

                items(groupTools) { tool ->
                    val isFav = favoriteScreens.contains(tool.screen.name)
                    DashboardToolCard(
                        tool = tool,
                        isFavorite = isFav,
                        onToggleFavorite = { onToggleFavorite(tool.screen.name) },
                        onClick = {
                            HapticUtils.performClick(context)
                            onNavigateToTool(tool.screen)
                        }
                    )
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------------------
// TAB 3: FAVOURITES TAB CONTENT
// -----------------------------------------------------------------------------------------
@Composable
private fun FavoritesTabContent(
    favoriteTools: List<ToolDefinition>,
    onToggleFavorite: (String) -> Unit,
    onNavigateToTool: (AppScreen) -> Unit,
    onBrowseTools: () -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "YOUR STARRED TOOLS (${favoriteTools.size})",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    letterSpacing = 1.sp
                )
            }
        }

        if (favoriteTools.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp)
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(ProGoldBg)
                        ) {
                            Icon(
                                imageVector = Icons.Default.StarBorder,
                                contentDescription = null,
                                tint = ProGold,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "No Starred Tools Yet",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Star any tool on Home or Categories to create your customized quick-access dashboard.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        Button(
                            onClick = {
                                HapticUtils.performClick(context)
                                onBrowseTools()
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ApsBlue)
                        ) {
                            Text("Browse All Tools", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            items(favoriteTools) { tool ->
                DashboardToolCard(
                    tool = tool,
                    isFavorite = true,
                    onToggleFavorite = { onToggleFavorite(tool.screen.name) },
                    onClick = {
                        HapticUtils.performClick(context)
                        onNavigateToTool(tool.screen)
                    }
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------------------
// TAB 4: PROFILE / SETTINGS TAB CONTENT
// -----------------------------------------------------------------------------------------
@Composable
private fun ProfileTabContent(
    isPremium: Boolean,
    themeMode: ThemeMode,
    onSetThemeMode: (ThemeMode) -> Unit,
    onGoPro: () -> Unit,
    onShareApp: () -> Unit,
    onRateUs: () -> Unit,
    onPrivacyPolicy: () -> Unit,
    onBuyCoffee: () -> Unit,
    onFeedback: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // App Profile Card Header
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.app_banner),
                        contentDescription = "App Icon",
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(18.dp))
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "APS TOOLS",
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp,
                        letterSpacing = 0.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Text(
                        text = "Version 2.4 (Production Release)",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(ApsBlue.copy(alpha = 0.1f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "100% Offline & Private • Zero Cloud Tracking",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ApsBlue
                        )
                    }
                }
            }
        }

        // PRO Upgrade Banner Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onGoPro)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = if (isPremium) {
                                    listOf(Color(0xFF065F46), Color(0xFF059669))
                                } else {
                                    listOf(Color(0xFFB45309), Color(0xFFF59E0B))
                                }
                            )
                        )
                        .padding(18.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.WorkspacePremium,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (isPremium) "PRO Lifetime Active" else "Unlock APS TOOLS PRO",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = if (isPremium) "Enjoy 100% ad-free experience" else "Remove banner & interstitial ads forever",
                                    fontSize = 12.sp,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // Preferences Section
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "PREFERENCES",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Dark Theme Mode Selector
                    Text("Theme Appearance", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        ThemeMode.values().forEach { mode ->
                            val isSelected = themeMode == mode
                            FilterChip(
                                selected = isSelected,
                                onClick = { onSetThemeMode(mode) },
                                label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = ApsBlue,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Support & Community Section
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "SUPPORT & COMMUNITY",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    SettingsActionRow(
                        icon = Icons.Default.Share,
                        title = "Share APS Tools",
                        subtitle = "Recommend to friends and colleagues",
                        onClick = onShareApp
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    SettingsActionRow(
                        icon = Icons.Default.ThumbUp,
                        title = "Rate Us on Play Store",
                        subtitle = "Help us grow with a 5-star review",
                        onClick = onRateUs
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    SettingsActionRow(
                        icon = Icons.Default.Feedback,
                        title = "Send In-App Feedback",
                        subtitle = "Report issues or suggest new utilities",
                        onClick = onFeedback
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    SettingsActionRow(
                        icon = Icons.Default.LocalCafe,
                        title = "Buy Developer a Coffee ☕",
                        subtitle = "Support independent open development",
                        onClick = onBuyCoffee
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    SettingsActionRow(
                        icon = Icons.Default.PrivacyTip,
                        title = "Privacy Policy",
                        subtitle = "Offline-first data security guarantee",
                        onClick = onPrivacyPolicy
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = ApsBlue,
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(text = subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.size(16.dp)
        )
    }
}

// -----------------------------------------------------------------------------------------
// REUSABLE SUB-COMPONENTS
// -----------------------------------------------------------------------------------------
@Composable
private fun ToolOfTheDayCard(
    tool: ToolDefinition,
    onOpen: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
            .testTag("tool_of_the_day_card")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF1E3A8A), // Deep Blue
                            Color(0xFF2563EB)  // Vibrant Aps Blue
                        )
                    )
                )
                .padding(18.dp)
        ) {
            Column {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFFBBF24))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "TOOL OF THE DAY",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF78350F),
                            letterSpacing = 0.8.sp
                        )
                    }

                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.2f))
                    ) {
                        Icon(
                            imageVector = tool.icon,
                            contentDescription = tool.title,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = tool.title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = tool.description,
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.85f),
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Open Now",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun RecentToolChipCard(
    tool: ToolDefinition,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .clickable(onClick = onClick)
            .width(130.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(12.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(tool.backgroundColor)
            ) {
                Icon(
                    imageVector = tool.icon,
                    contentDescription = tool.title,
                    tint = tool.accentColor,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = tool.title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun CategoryHeaderCard(
    category: ToolCategory,
    count: Int
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        Text(
            text = category.title,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onSurface
        )

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(ApsBlue.copy(alpha = 0.12f))
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Text(
                text = "$count Tools",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = ApsBlue
            )
        }
    }
}

@Composable
private fun DashboardToolCard(
    tool: ToolDefinition,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag(tool.testTag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Icon Box
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(tool.backgroundColor)
                ) {
                    Icon(
                        imageVector = tool.icon,
                        contentDescription = tool.title,
                        tint = tool.accentColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Category Tag
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(tool.backgroundColor)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = tool.category.title.uppercase(),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = tool.accentColor,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Favorite Pin Button
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("pin_favorite_${tool.screen.name}")
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = if (isFavorite) "Remove from favorites" else "Pin to favorites",
                            tint = if (isFavorite) Color(0xFFF59E0B) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = tool.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = tool.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 17.sp,
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Launch Tool",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = tool.accentColor
                )

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(tool.backgroundColor)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = tool.accentColor,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

// In-App Feedback Dialog
@Composable
private fun InAppFeedbackDialog(
    onDismiss: () -> Unit,
    onSubmit: (Int, String) -> Unit
) {
    var rating by remember { mutableStateOf(5) }
    var comment by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Share Your Feedback",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "How has your experience been with APS Tools?",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Star Rating
                Row(
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    for (i in 1..5) {
                        IconButton(onClick = { rating = i }) {
                            Icon(
                                imageVector = if (i <= rating) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = "$i Stars",
                                tint = if (i <= rating) ProGold else MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    placeholder = { Text("What tools would you like us to add or improve?") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    minLines = 3,
                    maxLines = 5
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(rating, comment) },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ApsBlue)
            ) {
                Text("Submit Feedback", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun MainDashboardScreen(modifier: Modifier = Modifier) {
    com.example.ui.ApsToolsApp(modifier = modifier)
}
