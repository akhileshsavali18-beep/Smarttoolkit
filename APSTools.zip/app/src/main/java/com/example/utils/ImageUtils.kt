package com.example.utils

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

object ImageUtils {

    fun loadBitmapFromUri(context: Context, uri: Uri, maxDimension: Int = 2048): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            }

            var inSampleSize = 1
            if (options.outHeight > maxDimension || options.outWidth > maxDimension) {
                val halfHeight = options.outHeight / 2
                val halfWidth = options.outWidth / 2
                while ((halfHeight / inSampleSize) >= maxDimension && (halfWidth / inSampleSize) >= maxDimension) {
                    inSampleSize *= 2
                }
            }

            val decodeOptions = BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
            }

            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, decodeOptions)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun getUriFileSize(context: Context, uri: Uri): Long {
        return try {
            var size: Long = -1
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val sizeIndex = it.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIndex != -1) {
                        size = it.getLong(sizeIndex)
                    }
                }
            }
            if (size <= 0) {
                context.contentResolver.openInputStream(uri)?.use {
                    size = it.available().toLong()
                }
            }
            size
        } catch (e: Exception) {
            e.printStackTrace()
            0L
        }
    }

    fun compressBitmap(bitmap: Bitmap, quality: Int): ByteArray {
        val stream = ByteArrayOutputStream()
        val safeQuality = quality.coerceIn(5, 100)
        bitmap.compress(Bitmap.CompressFormat.JPEG, safeQuality, stream)
        return stream.toByteArray()
    }

    fun resizeBitmap(bitmap: Bitmap, targetWidth: Int, targetHeight: Int): Bitmap {
        val safeWidth = targetWidth.coerceAtLeast(1)
        val safeHeight = targetHeight.coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, safeWidth, safeHeight, true)
    }

    fun saveBytesToCacheFile(context: Context, data: ByteArray, fileName: String): File {
        val dir = File(context.cacheDir, "compressed_images")
        if (!dir.exists()) dir.mkdirs()
        val file = File(dir, fileName)
        FileOutputStream(file).use {
            it.write(data)
            it.flush()
        }
        return file
    }

    fun generatePdfFromBitmaps(context: Context, bitmaps: List<Bitmap>, outputFileName: String = "APS_Tools_Document.pdf"): File {
        val pdfDocument = PdfDocument()

        // Standard A4 size in PostScript points: 595 x 842 points
        val pageWidth = 595
        val pageHeight = 842

        for (index in bitmaps.indices) {
            val bitmap = bitmaps[index]
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            // Fill white background
            canvas.drawColor(android.graphics.Color.WHITE)

            // Scale and center bitmap on page leaving 20pt margin
            val margin = 20f
            val availableWidth = pageWidth - (margin * 2)
            val availableHeight = pageHeight - (margin * 2)

            val widthRatio = availableWidth / bitmap.width.toFloat()
            val heightRatio = availableHeight / bitmap.height.toFloat()
            val scale = minOf(widthRatio, heightRatio)

            val scaledW = bitmap.width * scale
            val scaledH = bitmap.height * scale
            val left = margin + ((availableWidth - scaledW) / 2f)
            val top = margin + ((availableHeight - scaledH) / 2f)

            val matrix = Matrix().apply {
                postScale(scale, scale)
                postTranslate(left, top)
            }

            val paint = Paint(Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(bitmap, matrix, paint)

            pdfDocument.finishPage(page)
        }

        val outputDir = File(context.cacheDir, "pdf_exports")
        if (!outputDir.exists()) outputDir.mkdirs()
        val pdfFile = File(outputDir, outputFileName)
        FileOutputStream(pdfFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()
        return pdfFile
    }

    fun shareFile(context: Context, file: File, mimeType: String, chooserTitle: String = "Share File") {
        try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, chooserTitle))
        } catch (e: Exception) {
            // Fallback for direct share
            val uri = Uri.fromFile(file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
            }
            context.startActivity(Intent.createChooser(intent, chooserTitle))
        }
    }
}
